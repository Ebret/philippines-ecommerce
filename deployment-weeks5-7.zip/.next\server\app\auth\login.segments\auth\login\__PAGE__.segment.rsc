1:"$Sreact.fragment"
2:I[98238,["/_next/static/chunks/f3053dc513380deb.js","/_next/static/chunks/d227aef495ddd0fb.js","/_next/static/chunks/55f3191a7d5f3da7.js"],"LoginForm"]
3:I[99297,["/_next/static/chunks/c13d21c41b535736.js","/_next/static/chunks/509eb295113c8d90.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"f0gOV_Voy3t4-QgMd5hh8","rsc":["$","$1","c",{"children":[["$","div",null,{"className":"min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8","children":["$","div",null,{"className":"w-full max-w-md space-y-8","children":[["$","div",null,{"children":["$","h2",null,{"className":"mt-6 text-center text-3xl font-extrabold text-gray-900","children":"Sign in to your account"}]}],["$","$L2",null,{}]]}]}],[["$","script","script-0",{"src":"/_next/static/chunks/f3053dc513380deb.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/d227aef495ddd0fb.js","async":true}],["$","script","script-2",{"src":"/_next/static/chunks/55f3191a7d5f3da7.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
