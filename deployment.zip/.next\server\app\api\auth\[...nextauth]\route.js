var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/[...nextauth]/route.js")
R.c("server/chunks/[root-of-the-server]__5f872c68._.js")
R.c("server/chunks/600b5_bcryptjs_index_0b12279d.js")
R.c("server/chunks/[root-of-the-server]__86e0e327._.js")
R.c("server/chunks/[root-of-the-server]__bf77e2bb._.js")
R.c("server/chunks/a7675__next-internal_server_app_api_auth_[___nextauth]_route_actions_2fa55a9d.js")
R.m(3359)
module.exports=R.m(3359).exports
