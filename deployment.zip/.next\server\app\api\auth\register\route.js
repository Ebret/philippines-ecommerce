var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/register/route.js")
R.c("server/chunks/[root-of-the-server]__0df69550._.js")
R.c("server/chunks/600b5_bcryptjs_index_0b12279d.js")
R.c("server/chunks/600b5_zod_v4_classic_external_79941f1d.js")
R.c("server/chunks/[root-of-the-server]__86e0e327._.js")
R.c("server/chunks/600b5_next_a68c62f7._.js")
R.c("server/chunks/a7675__next-internal_server_app_api_auth_register_route_actions_3070dbc1.js")
R.m(50152)
module.exports=R.m(50152).exports
