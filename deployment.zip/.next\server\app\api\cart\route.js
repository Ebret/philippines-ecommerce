var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/cart/route.js")
R.c("server/chunks/[root-of-the-server]__19508d97._.js")
R.c("server/chunks/600b5_bcryptjs_index_0b12279d.js")
R.c("server/chunks/600b5_next_a68c62f7._.js")
R.c("server/chunks/[root-of-the-server]__bf77e2bb._.js")
R.c("server/chunks/[root-of-the-server]__86e0e327._.js")
R.c("server/chunks/4f3cd_philippines-ecommerce__next-internal_server_app_api_cart_route_actions_b4aa2ea6.js")
R.m(39055)
module.exports=R.m(39055).exports
