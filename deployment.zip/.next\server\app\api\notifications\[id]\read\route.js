var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/notifications/[id]/read/route.js")
R.c("server/chunks/[root-of-the-server]__f70af3cd._.js")
R.c("server/chunks/600b5_next_a68c62f7._.js")
R.c("server/chunks/[root-of-the-server]__bf77e2bb._.js")
R.c("server/chunks/[root-of-the-server]__86e0e327._.js")
R.c("server/chunks/a7675__next-internal_server_app_api_notifications_[id]_read_route_actions_8106e6d4.js")
R.m(59490)
module.exports=R.m(59490).exports
