1:"$Sreact.fragment"
2:I[13526,["/_next/static/chunks/381592ddf560d983.js","/_next/static/chunks/d227aef495ddd0fb.js"],"ForgotPasswordForm"]
3:I[99297,["/_next/static/chunks/c13d21c41b535736.js","/_next/static/chunks/509eb295113c8d90.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"K0PgGbU2Kgk0C9CxoHjqP","rsc":["$","$1","c",{"children":[["$","div",null,{"className":"min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8","children":["$","div",null,{"className":"w-full max-w-md space-y-8","children":[["$","div",null,{"children":[["$","h2",null,{"className":"mt-6 text-center text-3xl font-extrabold text-gray-900","children":"Reset your password"}],["$","p",null,{"className":"mt-2 text-center text-sm text-gray-600","children":"Enter your email address and we'll send you a link to reset your password."}]]}],["$","$L2",null,{}]]}]}],[["$","script","script-0",{"src":"/_next/static/chunks/381592ddf560d983.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/d227aef495ddd0fb.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
