1:"$Sreact.fragment"
2:I[99297,["/_next/static/chunks/c13d21c41b535736.js","/_next/static/chunks/509eb295113c8d90.js"],"ViewportBoundary"]
4:I[99297,["/_next/static/chunks/c13d21c41b535736.js","/_next/static/chunks/509eb295113c8d90.js"],"MetadataBoundary"]
5:"$Sreact.suspense"
7:I[84155,["/_next/static/chunks/c13d21c41b535736.js","/_next/static/chunks/509eb295113c8d90.js"],"IconMark"]
:HL["/_next/static/chunks/71a1cfc0acfa0752.css","style"]
:HL["/_next/static/media/797e433ab948586e-s.p.dbea232f.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/caa3a2e1cccd8315-s.p.853070df.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
0:{"buildId":"K0PgGbU2Kgk0C9CxoHjqP","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"auth","paramType":null,"paramKey":"auth","hasRuntimePrefetch":false,"slots":{"children":{"name":"register","paramType":null,"paramKey":"register","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"head":["$","$1","h",{"children":[null,["$","$L2",null,{"children":"$@3"}],["$","div",null,{"hidden":true,"children":["$","$L4",null,{"children":["$","$5",null,{"name":"Next.Metadata","children":"$@6"}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"isHeadPartial":false,"staleTime":300}
3:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
6:[["$","title","0",{"children":"Create Account | Philippines E-Commerce"}],["$","meta","1",{"name":"description","content":"Create a new account"}],["$","link","2",{"rel":"icon","href":"/favicon.ico?favicon.0b3bf435.ico","sizes":"256x256","type":"image/x-icon"}],["$","$L7","3",{}]]
