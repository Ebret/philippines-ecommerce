1:"$Sreact.fragment"
2:I[86735,["/_next/static/chunks/c90b8d9d5cfca15c.js","/_next/static/chunks/031f7ab197db6adb.js","/_next/static/chunks/d227aef495ddd0fb.js"],"RegisterForm"]
3:I[99297,["/_next/static/chunks/c13d21c41b535736.js","/_next/static/chunks/509eb295113c8d90.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"K0PgGbU2Kgk0C9CxoHjqP","rsc":["$","$1","c",{"children":[["$","div",null,{"className":"min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8","children":["$","div",null,{"className":"w-full max-w-md space-y-8","children":[["$","div",null,{"children":["$","h2",null,{"className":"mt-6 text-center text-3xl font-extrabold text-gray-900","children":"Create your account"}]}],["$","$L2",null,{}]]}]}],[["$","script","script-0",{"src":"/_next/static/chunks/c90b8d9d5cfca15c.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/031f7ab197db6adb.js","async":true}],["$","script","script-2",{"src":"/_next/static/chunks/d227aef495ddd0fb.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
