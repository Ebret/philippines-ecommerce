1:"$Sreact.fragment"
2:"$Sreact.suspense"
3:I[34956,["/_next/static/chunks/10d87bfef2151ffa.js","/_next/static/chunks/d227aef495ddd0fb.js"],"ResetPasswordForm"]
4:I[99297,["/_next/static/chunks/c13d21c41b535736.js","/_next/static/chunks/509eb295113c8d90.js"],"OutletBoundary"]
0:{"buildId":"K0PgGbU2Kgk0C9CxoHjqP","rsc":["$","$1","c",{"children":[["$","div",null,{"className":"min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8","children":["$","div",null,{"className":"w-full max-w-md space-y-8","children":[["$","div",null,{"children":["$","h2",null,{"className":"mt-6 text-center text-3xl font-extrabold text-gray-900","children":"Create a new password"}]}],["$","$2",null,{"fallback":["$","div",null,{"children":"Loading..."}],"children":["$","$L3",null,{}]}]]}]}],[["$","script","script-0",{"src":"/_next/static/chunks/10d87bfef2151ffa.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/d227aef495ddd0fb.js","async":true}]],["$","$L4",null,{"children":["$","$2",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
